export type Player = {
  id: number;
  name: string | null;
  license: string | null;
  steam: string | null;
  discord: string | null;
  rockstar: string | null;
  trust_score: number | null;
  last_seen: string | null;
};

export type EventRow = {
  id: number;
  player_id: number | null;
  server_name: string | null;
  code: string;
  severity: string | null;
  detail: any;
  created_at: string;
  player?: Player;
};

export type Ban = {
  id: number;
  player_id: number;
  reason: string | null;
  created_by: string | null;
  created_at: string;
  revoked_at: string | null;
};
