"use client";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import type { Ban } from "@/lib/types";

export default function Bans() {
  const [bans, setBans] = useState<Ban[]>([]);
  const [q, setQ] = useState("");

  useEffect(() => {
    supabase.from("bans").select("*").order("created_at", { ascending: false }).limit(200)
      .then(({ data }) => setBans(data || []));

    const channel = supabase
      .channel("bans-live")
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "bans" }, (payload: any) => {
        setBans((prev) => [payload.new as Ban, ...prev].slice(0, 200));
      }).subscribe();

    return () => { supabase.removeChannel(channel); };
  }, []);

  const filtered = bans.filter(b => !q || (b.reason || "").toLowerCase().includes(q.toLowerCase()));

  return (
    <div className="grid gap-4">
      <div className="flex gap-2">
        <input className="input w-80" placeholder="Search reason..." value={q} onChange={e=>setQ(e.target.value)} />
        <button className="btn" onClick={()=>setQ("")}>Clear</button>
      </div>
      <div className="card">
        <div className="text-lg font-semibold mb-2">Bans</div>
        <div className="grid gap-2">
          {filtered.map(b => (
            <div key={b.id} className="grid grid-cols-[1fr_200px_160px] border-b border-[#1f2335] py-2">
              <div>
                <div className="font-medium">{b.reason ?? "Banned"}</div>
                <div className="text-slate-400 text-sm">Player #{b.player_id}</div>
              </div>
              <div className="text-slate-400">{new Date(b.created_at).toLocaleString()}</div>
              <div className="text-slate-400">{b.created_by}</div>
            </div>
          ))}
          {filtered.length === 0 && <div className="text-slate-400">No bans recorded.</div>}
        </div>
      </div>
    </div>
  );
}
