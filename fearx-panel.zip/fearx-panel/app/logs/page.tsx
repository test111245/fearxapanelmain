"use client";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import type { EventRow } from "@/lib/types";
import { timeAgo } from "@/lib/utils";

export default function Logs() {
  const [events, setEvents] = useState<EventRow[]>([]);
  const [query, setQuery] = useState("");

  useEffect(() => {
    supabase.from("events")
      .select("*").order("created_at", { ascending: false }).limit(200)
      .then(({ data }) => setEvents(data || []));

    const channel = supabase
      .channel("events-log")
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "events" }, (payload: any) => {
        setEvents((prev) => {
          const next = [payload.new as EventRow, ...prev];
          return next.slice(0, 500);
        });
      }).subscribe();

    return () => { supabase.removeChannel(channel); };
  }, []);

  const filtered = events.filter(e =>
    !query ||
    e.code?.toLowerCase().includes(query.toLowerCase()) ||
    JSON.stringify(e.detail || {}).toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="grid gap-4">
      <div className="flex gap-2">
        <input className="input w-80" placeholder="Filter by code or detail..." value={query} onChange={e=>setQuery(e.target.value)} />
        <button className="btn" onClick={()=>setQuery("")}>Clear</button>
      </div>
      <div className="card overflow-auto">
        <table className="w-full text-sm">
          <thead className="text-slate-400">
            <tr className="text-left border-b border-[#1f2335]">
              <th className="py-2 pr-4">Time</th>
              <th className="py-2 pr-4">Code</th>
              <th className="py-2 pr-4">Severity</th>
              <th className="py-2 pr-4">Server</th>
              <th className="py-2">Detail</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(ev => (
              <tr key={ev.id} className="border-b border-[#1f2335]">
                <td className="py-2 pr-4 text-slate-400">{timeAgo(ev.created_at)}</td>
                <td className="py-2 pr-4 font-medium">{ev.code}</td>
                <td className="py-2 pr-4">{ev.severity}</td>
                <td className="py-2 pr-4">{ev.server_name}</td>
                <td className="py-2">{ev.detail ? JSON.stringify(ev.detail) : ""}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && <div className="text-slate-400">No events yet.</div>}
      </div>
    </div>
  );
}
