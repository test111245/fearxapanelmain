"use client";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import type { EventRow } from "@/lib/types";

export default function Dashboard() {
  const [online, setOnline] = useState(0);
  const [max, setMax] = useState(32);
  const [recent, setRecent] = useState<EventRow[]>([]);

  useEffect(() => {
    // Initial load of latest events
    supabase.from("events").select("*").order("created_at", { ascending: false }).limit(10)
      .then(({ data }) => setRecent(data || []));

    // Listen live
    const sub = supabase.channel("events-changes")
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "events" }, (payload: any) => {
        setRecent(prev => [payload.new as EventRow, ...prev].slice(0, 10));
      }).subscribe();

    return () => { supabase.removeChannel(sub); };
  }, []);

  return (
    <div className="grid gap-4">
      <div className="grid grid-cols-4 gap-4">
        <div className="card">
          <div className="text-slate-400 text-sm">Online Players</div>
          <div className="text-3xl font-bold mt-2">{online}</div>
          <div className="text-slate-400 text-xs">of {max}</div>
        </div>
        <div className="card">
          <div className="text-slate-400 text-sm">Events (last 10)</div>
          <div className="text-3xl font-bold mt-2">{recent.length}</div>
          <div className="text-slate-400 text-xs">live</div>
        </div>
        <div className="card">
          <div className="text-slate-400 text-sm">Server</div>
          <div className="text-3xl font-bold mt-2">Active</div>
          <div className="text-slate-400 text-xs">Realtime connected</div>
        </div>
        <div className="card">
          <div className="text-slate-400 text-sm">Panel</div>
          <div className="text-3xl font-bold mt-2">FearX</div>
          <div className="text-slate-400 text-xs">App Router</div>
        </div>
      </div>

      <div className="card">
        <div className="text-lg font-semibold">Recent Activity</div>
        <div className="mt-2 grid gap-2">
          {recent.length === 0 && <div className="text-slate-400">Waiting for events...</div>}
          {recent.map((e) => (
            <div key={e.id} className="grid grid-cols-[100px_1fr] gap-4 border-b border-[#1f2335] pb-2">
              <div className="text-slate-400 text-sm">{new Date(e.created_at).toLocaleTimeString()}</div>
              <div>
                <div className="font-medium">{e.code}</div>
                <div className="text-slate-400 text-sm">{e.detail ? JSON.stringify(e.detail) : ""}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
