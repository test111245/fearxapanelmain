import "./globals.css";
import Link from "next/link";
import { ReactNode } from "react";
import { cn } from "@/lib/utils";

export const metadata = {
  title: process.env.NEXT_PUBLIC_PANEL_NAME || "FearX Panel",
  description: "Live anti-cheat dashboard"
};

const Nav = ({ pathname }: { pathname: string }) => {
  const items = [
    { href: "/dashboard", label: "Dashboard", icon: "📊" },
    { href: "/logs", label: "Live Logs", icon: "📜" },
    { href: "/players", label: "Players", icon: "👥" },
    { href: "/bans", label: "Bans", icon: "🚫" }
  ];
  return (
    <aside className="bg-[#0f1220] border-r border-[#1f2335] p-4 w-64 min-h-screen">
      <div className="py-2 pb-4 border-b border-[#1f2335]">
        <div className="text-xl font-semibold">FearX Panel</div>
        <div className="text-sm text-slate-400">Live monitoring</div>
      </div>
      <nav className="mt-4 grid gap-1">
        {items.map(i => (
          <Link key={i.href} href={i.href} className={cn("navlink", pathname.startsWith(i.href) && "navlink-active")}>
            <span>{i.icon}</span><span>{i.label}</span>
          </Link>
        ))}
      </nav>
    </aside>
  );
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <div className="grid grid-cols-[16rem_1fr]">
          {/* @ts-expect-error server component */}
          <Nav pathname={""} />
          <main className="p-4">{children}</main>
        </div>
      </body>
    </html>
  );
}
