"use client";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import type { Player } from "@/lib/types";

export default function Players() {
  const [players, setPlayers] = useState<Player[]>([]);
  const [q, setQ] = useState("");

  useEffect(() => {
    supabase.from("players").select("*").order("last_seen", { ascending: false }).limit(200)
      .then(({ data }) => setPlayers(data || []));

    const channel = supabase
      .channel("players-list")
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "players" }, () => {
        supabase.from("players").select("*").order("last_seen", { ascending: false }).limit(200)
          .then(({ data }) => setPlayers(data || []));
      })
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, []);

  const filtered = players.filter(p =>
    !q || (p.name || "").toLowerCase().includes(q.toLowerCase()) || String(p.id).includes(q)
  );

  return (
    <div className="grid gap-4">
      <div className="flex gap-2 items-center">
        <input className="input w-80" placeholder="Search by name or ID..." value={q} onChange={e=>setQ(e.target.value)} />
        <div className="text-slate-400 text-sm">{filtered.length} results</div>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="card">
          <div className="text-lg font-semibold mb-2">Players</div>
          <div className="grid gap-2 max-h-[70vh] overflow-auto">
            {filtered.map((p) => (
              <div key={p.id} className="grid grid-cols-[1fr_80px_80px] items-center border-b border-[#1f2335] py-2">
                <div className="font-medium">{p.name ?? 'Unknown'}</div>
                <div className="text-slate-400 text-sm">ID {p.id}</div>
                <div className="text-slate-400 text-sm">{p.trust_score ?? 0}</div>
              </div>
            ))}
            {filtered.length === 0 && <div className="text-slate-400">No players yet.</div>}
          </div>
        </div>
        <div className="card">
          <div className="text-lg font-semibold mb-2">Details</div>
          <div className="text-slate-400 text-sm">Select a player to view more (TODO: actions)</div>
        </div>
      </div>
    </div>
  );
}
