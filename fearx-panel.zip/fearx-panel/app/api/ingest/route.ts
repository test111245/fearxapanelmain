import { NextRequest, NextResponse } from "next/server";
import { supabaseServer } from "@/lib/supabaseServer";

// POST /api/ingest
// headers: Authorization: Bearer <FEARX_API_KEY>
// body: { type, server_name, player: { id, name, license, steam, discord, rockstar }, code, severity, detail }
export async function POST(req: NextRequest) {
  const auth = req.headers.get("authorization");
  if (!auth || auth !== `Bearer ${process.env.FEARX_API_KEY}`) {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }
  const db = supabaseServer();
  const body = await req.json();

  const p = body.player || {};
  // upsert player by (license || steam || discord || rockstar || name)
  const identity = p.license || p.steam || p.discord || p.rockstar || p.name;
  let playerId: number | null = null;

  if (identity) {
    const { data: found, error: findErr } = await db.from("players")
      .select("*").or([
        p.license ? `license.eq.${p.license}` : "",
        p.steam ? `steam.eq.${p.steam}` : "",
        p.discord ? `discord.eq.${p.discord}` : "",
        p.rockstar ? `rockstar.eq.${p.rockstar}` : ""
      ].filter(Boolean).join(","))
      .limit(1);
    if (findErr) console.error(findErr);

    if (found && found.length) {
      playerId = found[0].id;
      await db.from("players").update({
        name: p.name || found[0].name,
        last_seen: new Date().toISOString()
      }).eq("id", playerId);
    } else {
      const { data: ins, error: insErr } = await db.from("players").insert([{
        name: p.name || null,
        license: p.license || null,
        steam: p.steam || null,
        discord: p.discord || null,
        rockstar: p.rockstar || null,
        last_seen: new Date().toISOString()
      }]).select("*").limit(1);
      if (insErr) console.error(insErr);
      playerId = ins?.[0]?.id ?? null;
    }
  }

  // insert event
  const { error: evErr } = await db.from("events").insert([{
    player_id: playerId,
    server_name: body.server_name || null,
    code: body.code || "unknown",
    severity: body.severity || "info",
    detail: body.detail || {}
  }]);
  if (evErr) {
    console.error(evErr);
    return NextResponse.json({ ok: false }, { status: 500 });
  }
  return NextResponse.json({ ok: true });
}
