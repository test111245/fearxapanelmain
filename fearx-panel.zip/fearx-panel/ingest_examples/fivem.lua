-- Example FiveM ingestion snippet for FearX Panel
local PANEL_URL = "https://your-vercel-app.vercel.app/api/ingest"
local API_KEY   = "CHANGE_ME"

function FearX_SendEvent(ev)
  PerformHttpRequest(PANEL_URL, function(code, res)
    print("[FearX Panel] ingest status", code)
  end, "POST", json.encode(ev), {
    ["Content-Type"] = "application/json",
    ["Authorization"] = ("Bearer %s"):format(API_KEY)
  })
end

-- Example usage:
RegisterCommand("fx_test_event", function(src)
  local name = GetPlayerName(src) or "Unknown"
  FearX_SendEvent({
    server_name = GetConvar("sv_hostname", "My Server"),
    player = { id = src, name = name },
    code = "test_violation",
    severity = "info",
    detail = { hello = "world" }
  })
end)
